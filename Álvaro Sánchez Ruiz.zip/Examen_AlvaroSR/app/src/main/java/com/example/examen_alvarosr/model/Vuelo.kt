package com.example.examen_alvarosr.model

data class Vuelo (var origen: String, var destino: String, var ida: String, var vuelta: String, var imagenOrigen: Int, var imagenDestino: Int) {
}